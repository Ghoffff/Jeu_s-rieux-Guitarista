import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF6F35A5);
const kPrimaryLightColor = Color(0xFFF1E6FF);
const Color correct= Color(0xFF32AB58);
const Color incorrect= Color(0xFFAB3232);
const Color background= Color(0xFF2238A1);

